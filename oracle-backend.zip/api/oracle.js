import fetch from "node-fetch";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Nur POST erlaubt" });
  }

  try {
    const { question } = req.body;

    if (!question) {
      return res.status(400).json({ error: "Keine Frage übergeben" });
    }

    // Anfrage an OpenAI API
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Du bist ein mystisches Orakel. Antworte weise, geheimnisvoll und poetisch." },
          { role: "user", content: question }
        ],
        max_tokens: 200
      })
    });

    const data = await response.json();

    if (!data.choices || !data.choices[0].message) {
      return res.status(500).json({ error: "Fehler bei der Antwort vom Orakel" });
    }

    res.status(200).json({ answer: data.choices[0].message.content });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Interner Serverfehler" });
  }
}